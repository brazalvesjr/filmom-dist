# -*- coding: utf-8 -*-
"""Camada de reprodução do FILMOM.

Esta camada entrega URLs ao player do Kodi com configuração mais explícita para
reduzir falhas comuns de IPTV, especialmente em canais ao vivo. Ela prioriza HLS
com InputStream Adaptive quando a URL for compatível e mantém fallback nativo
para TS/MP4/MKV. Nenhum addon consegue impedir quedas causadas por servidor,
internet, limite de conta ou token expirado, mas estas propriedades reduzem
interrupções por detecção incorreta, headers ausentes e abertura pesada.
"""

from __future__ import absolute_import, unicode_literals

import re
import socket
import sys
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

USER_AGENT = "Mozilla/5.0 (Linux; Android 11; Kodi) AppleWebKit/537.36 FILMOM/1.0"
COMMON_HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "*/*",
    "Connection": "keep-alive",
    "Icy-MetaData": "0",
}


def _has_inputstream_adaptive():
    try:
        xbmcaddon.Addon("inputstream.adaptive")
        return bool(xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"))
    except Exception:
        return False


def _split_url_headers(url):
    if "|" not in (url or ""):
        return url or "", {}
    base, header_text = url.split("|", 1)
    parsed = {}
    for key, values in urllib.parse.parse_qs(header_text, keep_blank_values=True).items():
        if values:
            parsed[key] = values[-1]
    return base, parsed


def _headers_string(extra=None):
    headers = dict(COMMON_HEADERS)
    headers.update(extra or {})
    return urllib.parse.urlencode(headers)


def _url_with_headers(url, extra=None):
    base, existing = _split_url_headers(url)
    existing.update(extra or {})
    return base + "|" + _headers_string(existing)


def _extension_from_url(url):
    base, _headers = _split_url_headers(url)
    path = urllib.parse.urlparse(base).path.lower()
    match = re.search(r"\.([a-z0-9]{2,5})$", path)
    return match.group(1) if match else ""


def _is_hls(url):
    return _extension_from_url(url) == "m3u8" or ".m3u8" in (url or "").lower()


def _mime_for_url(url):
    ext = _extension_from_url(url)
    if ext == "m3u8":
        return "application/vnd.apple.mpegurl"
    if ext == "ts":
        return "video/mp2t"
    if ext == "mkv":
        return "video/x-matroska"
    if ext == "avi":
        return "video/x-msvideo"
    return "video/mp4"


def _safe_call(obj, method, *args, **kwargs):
    try:
        getattr(obj, method)(*args, **kwargs)
    except Exception:
        pass


def apply_fast_playback_properties(item, url, mediatype="video"):
    """Aplica propriedades comuns para início rápido e reprodução estável."""
    item.setProperty("IsPlayable", "true")
    item.setProperty("mediatype", mediatype or "video")
    _safe_call(item, "setMimeType", _mime_for_url(url))
    _safe_call(item, "setContentLookup", False)

    if _is_hls(url) and _has_inputstream_adaptive():
        headers = _headers_string()
        item.setProperty("inputstream", "inputstream.adaptive")
        item.setProperty("inputstreamaddon", "inputstream.adaptive")
        item.setProperty("inputstream.adaptive.manifest_type", "hls")
        item.setProperty("inputstream.adaptive.manifest_headers", headers)
        item.setProperty("inputstream.adaptive.stream_headers", headers)
        item.setProperty("inputstream.adaptive.common_headers", headers)
    return item


def _url_responds_quickly(url, timeout=2):
    if not url:
        return False
    base, _headers = _split_url_headers(url)
    req = urllib.request.Request(base, headers=COMMON_HEADERS)
    try:
        socket.setdefaulttimeout(timeout)
        with urllib.request.urlopen(req, timeout=timeout) as response:
            data = response.read(768)
            code = getattr(response, "status", response.getcode())
        if int(code) >= 400:
            return False
        if _is_hls(base):
            return b"#EXTM3U" in data or b"#EXTINF" in data or bool(data)
        return True
    except (urllib.error.URLError, urllib.error.HTTPError, socket.timeout, ValueError, OSError):
        xbmc.log("[FILMOM] URL principal não respondeu rápido; usando fallback quando disponível: %s" % base, xbmc.LOGWARNING)
        return False


def choose_playback_url(url, fallback_url=""):
    """Escolhe a URL com menor risco de falha antes de entregar ao Kodi."""
    if _is_hls(url) and fallback_url and not _url_responds_quickly(url):
        return fallback_url
    return url


def playable_item(title, url, thumb="", fanart="", plot="", mediatype="video"):
    item = xbmcgui.ListItem(label=title or "FILMOM")
    art = thumb or fanart
    item.setArt({"icon": art, "thumb": art, "poster": art, "fanart": fanart or thumb})
    item.setInfo("video", {
        "title": title or "FILMOM",
        "plot": plot or "Sinopse não informada pelo servidor.",
        "mediatype": mediatype or "video"
    })
    apply_fast_playback_properties(item, url, mediatype)
    item.setPath(_url_with_headers(url))
    return item


def resolve(url, title="FILMOM", thumb="", fanart="", plot="", fallback_url=""):
    if not url:
        xbmcgui.Dialog().notification("FILMOM", "URL de reprodução inválida.", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        return
    selected_url = choose_playback_url(url, fallback_url)
    item = playable_item(title, selected_url, thumb, fanart, plot)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def add_context_play_properties(item, url):
    return apply_fast_playback_properties(item, url)
