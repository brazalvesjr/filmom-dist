# -*- coding: utf-8 -*-
"""Proxy HLS/TS interno do FILMOM para o modo F4M.

Este módulo expõe a mesma interface mínima usada pelo FILMOM ao carregar o
`server.py` do F4MTESTER: classe ``mediaserver`` e função ``prepare_url``.
Ele evita que o player selecionado caia para NATIVO apenas porque o addon
externo ``plugin.video.f4mTester`` foi removido, desativado ou ficou invisível
no banco de addons do Kodi.
"""

from __future__ import absolute_import, unicode_literals

import threading
import time

try:
    from http.server import HTTPServer, SimpleHTTPRequestHandler
except ImportError:  # pragma: no cover - compatibilidade legada
    from BaseHTTPServer import HTTPServer
    from SimpleHTTPServer import SimpleHTTPRequestHandler

try:
    from urllib.parse import quote_plus, unquote, unquote_plus, urlparse
    from urllib.request import Request, urlopen
except ImportError:  # pragma: no cover - compatibilidade legada
    from urllib import quote_plus, unquote, unquote_plus
    from urlparse import urlparse
    from urllib2 import Request, urlopen

HOST_NAME = "127.0.0.1"
PORT_NUMBER = 55333
DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0 Safari/537.36"

GLOBAL_HEADERS = {}
GLOBAL_URL = ""
_SERVER = None
_SERVER_LOCK = threading.Lock()


def _decode(value):
    value = value or ""
    for decoder in (unquote_plus, unquote):
        try:
            value = decoder(value)
        except Exception:
            pass
    return value


def _basename(path):
    index = path.rfind("/") + 1
    return path[index:]


def _parse_headers(raw_url):
    global GLOBAL_HEADERS
    url = raw_url or ""
    headers = {"User-Agent": DEFAULT_USER_AGENT, "Connection": "keep-alive"}
    if "|" in url:
        _base, header_text = url.split("|", 1)
    elif "&h123" in url:
        _base, header_text = url.split("&h123", 1)
    else:
        header_text = ""
    if header_text:
        header_text = header_text.replace("true&", "").lstrip("&")
        for part in header_text.split("&"):
            if "=" not in part:
                continue
            key, value = part.split("=", 1)
            key = key.strip()
            if key in ("User-Agent", "Referer", "Origin", "Cookie", "Authorization"):
                headers[key] = _decode(value)
    GLOBAL_HEADERS = headers
    return headers


def _strip_transport_headers(url):
    url = url or ""
    if "|" in url:
        return url.split("|", 1)[0]
    if "&h123" in url:
        return url.split("&h123", 1)[0]
    return url


def _convert_to_m3u8(url):
    url = _strip_transport_headers(url)
    try:
        if ".m3u8" not in url and "/hl" not in url and int(url.count(":")) == 2 and int(url.count("/")) > 4:
            parsed_url = urlparse(url)
            host_part = "%s://%s" % (parsed_url.scheme, parsed_url.netloc)
            tail = url.split(host_part, 1)[1]
            url = host_part + "/live" + tail
            file_name = _basename(url)
            if ".ts" in file_name:
                url = url.replace(file_name, file_name.replace(".ts", ".m3u8"))
            else:
                url = url.replace(file_name, file_name + ".m3u8")
    except Exception:
        pass
    return url


def _open_remote(url, headers=None, method="GET", timeout=8):
    request = Request(url, headers=headers or {"User-Agent": DEFAULT_USER_AGENT})
    try:
        request.get_method = lambda: method
    except Exception:
        pass
    return urlopen(request, timeout=timeout)


class handler(SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        return

    def _extract_url(self):
        try:
            raw = self.path.split("url=", 1)[1]
        except Exception:
            raw = ""
        return _decode(raw)

    def _send_empty(self, status=200):
        self.send_response(status)
        self.end_headers()

    def _handle_control(self):
        if self.path == "/check":
            self._send_empty(200)
            return True
        if self.path == "/stop":
            self._send_empty(200)
            server = self.server
            thread = threading.Thread(target=server.shutdown)
            thread.daemon = True
            thread.start()
            return True
        return False

    def _resolve_relative(self, url):
        global GLOBAL_URL
        if url and not url.startswith("http") and GLOBAL_URL:
            return GLOBAL_URL + url.lstrip("/")
        if not url and ".ts" in self.path and GLOBAL_URL:
            return GLOBAL_URL + self.path.lstrip("/")
        return url

    def _proxy_ts(self, url, head=False):
        headers = GLOBAL_HEADERS or {"User-Agent": DEFAULT_USER_AGENT}
        url = self._resolve_relative(url)
        if not url:
            self._send_empty(404)
            return
        if head:
            self._send_empty(200)
            return
        try:
            response = _open_remote(url, headers=headers, timeout=12)
            self.send_response(200)
            self.send_header("Content-Type", "video/mp2t")
            self.end_headers()
            while True:
                chunk = response.read(64 * 1024)
                if not chunk:
                    break
                self.wfile.write(chunk)
            try:
                response.close()
            except Exception:
                pass
        except Exception:
            self._send_empty(404)

    def _absolute_playlist(self, text, source_url):
        global GLOBAL_URL
        parsed = urlparse(source_url)
        base_host = "%s://%s" % (parsed.scheme, parsed.netloc)
        source_file = _basename(source_url)
        base_url = source_url.replace(source_file, "")
        if not base_url.endswith("/"):
            base_url += "/"
        GLOBAL_URL = base_url

        def proxify(value):
            return "http://%s:%s/?url=%s" % (HOST_NAME, PORT_NUMBER, quote_plus(value))

        output = []
        for line in (text or "").splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                output.append(line)
                continue
            if stripped.startswith("http://") or stripped.startswith("https://"):
                output.append(proxify(stripped))
            elif stripped.startswith("/"):
                output.append(proxify(base_host + stripped))
            else:
                output.append(proxify(base_url + stripped))
        return "\n".join(output) + "\n"

    def _proxy_m3u8(self, url, head=False):
        headers = GLOBAL_HEADERS or {"User-Agent": DEFAULT_USER_AGENT}
        url = self._resolve_relative(url)
        if not url:
            self._send_empty(404)
            return
        if head:
            self._send_empty(200)
            return
        for _attempt in range(8):
            try:
                response = _open_remote(url, headers=headers, timeout=6)
                raw = response.read()
                try:
                    text = raw.decode("utf-8", "ignore")
                except Exception:
                    text = str(raw)
                text = self._absolute_playlist(text, response.geturl() or url)
                self.send_response(200)
                self.send_header("Content-Type", "application/vnd.apple.mpegurl")
                self.end_headers()
                self.wfile.write(text.encode("utf-8"))
                try:
                    response.close()
                except Exception:
                    pass
                return
            except Exception:
                time.sleep(1)
        self._send_empty(404)

    def _dispatch(self, head=False):
        if self._handle_control():
            return
        raw_url = self._extract_url()
        if raw_url:
            _parse_headers(raw_url)
        url = _convert_to_m3u8(raw_url) if raw_url else self._resolve_relative("")
        if ".m3u8" in (url or self.path):
            self._proxy_m3u8(url, head=head)
        elif (url or self.path).endswith(".ts") or "/hl" in (url or self.path) or (url or "").endswith(".html"):
            self._proxy_ts(url, head=head)
        else:
            self._proxy_ts(url, head=head)

    def do_HEAD(self):
        self._dispatch(head=True)

    def do_GET(self):
        self._dispatch(head=False)


def _serve_forever(server):
    try:
        server.serve_forever()
    finally:
        try:
            server.server_close()
        except Exception:
            pass


class mediaserver(object):
    def __init__(self):
        self.httpd = None
        self.server = None

    def in_use(self):
        try:
            response = _open_remote("http://%s:%s/check" % (HOST_NAME, PORT_NUMBER), method="HEAD", timeout=1)
            code = getattr(response, "code", None) or response.getcode()
            try:
                response.close()
            except Exception:
                pass
            return code == 200
        except Exception:
            return False

    def start(self):
        global _SERVER
        if self.in_use():
            return
        with _SERVER_LOCK:
            if self.in_use():
                return
            self.httpd = HTTPServer(("", PORT_NUMBER), handler)
            _SERVER = self.httpd
            self.server = threading.Thread(target=_serve_forever, args=(self.httpd,))
            self.server.daemon = True
            self.server.start()
        time.sleep(1)

    def stop(self):
        global _SERVER
        try:
            if self.httpd:
                self.httpd.shutdown()
        except Exception:
            pass
        _SERVER = None


def prepare_url(url):
    url = _decode(url)
    url = url.replace("|", "&h123=true&")
    return "http://%s:%s/?url=%s" % (HOST_NAME, PORT_NUMBER, quote_plus(url))


def req_shutdown():
    try:
        response = _open_remote("http://%s:%s/stop" % (HOST_NAME, PORT_NUMBER), timeout=2)
        response.close()
    except Exception:
        pass
