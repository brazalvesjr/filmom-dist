# -*- coding: utf-8 -*-
"""Camada de reprodução do FILMOM.

A reprodução mantém o modo NATIVO RÁPIDO (TS) como padrão e permite alternar
para o addon externo F4MTESTER quando o player nativo do Kodi estiver instável.
O F4MTESTER não é empacotado no FILMOM; ele é chamado somente quando instalado
no Kodi do usuário e selecionado na opção TROCA DE PLAYER.
"""

from __future__ import absolute_import, unicode_literals

import importlib.util
import os
import re
import sys
import threading
import time
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

USER_AGENT = "Mozilla/5.0 (Linux; Android 11; Kodi) AppleWebKit/537.36 FILMOM/1.0"
F4MTESTER_ADDON_ID = "plugin.video.f4mTester"
F4MTESTER_PROXY_HOST = "127.0.0.1"
F4MTESTER_PROXY_PORT = 55333
COMMON_HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "*/*",
    "Connection": "keep-alive",
    "Icy-MetaData": "0",
}


def _split_url_headers(url):
    if "|" not in (url or ""):
        return url or "", {}
    base, header_text = url.split("|", 1)
    parsed = {}
    for key, values in urllib.parse.parse_qs(header_text, keep_blank_values=True).items():
        if values:
            parsed[key] = values[-1]
    return base, parsed


def _headers_string(extra=None):
    headers = dict(COMMON_HEADERS)
    headers.update(extra or {})
    return urllib.parse.urlencode(headers)


def _url_with_headers(url, extra=None):
    base, existing = _split_url_headers(url)
    existing.update(extra or {})
    return base + "|" + _headers_string(existing)


def _extension_from_url(url):
    base, _headers = _split_url_headers(url)
    path = urllib.parse.urlparse(base).path.lower()
    match = re.search(r"\.([a-z0-9]{2,5})$", path)
    return match.group(1) if match else ""


def _mime_for_url(url):
    ext = _extension_from_url(url)
    if ext == "ts":
        return "video/mp2t"
    if ext == "mkv":
        return "video/x-matroska"
    if ext == "avi":
        return "video/x-msvideo"
    if ext == "m3u8":
        return "application/vnd.apple.mpegurl"
    return "video/mp4"


def _safe_call(obj, method, *args, **kwargs):
    try:
        getattr(obj, method)(*args, **kwargs)
    except Exception:
        pass


def apply_fast_playback_properties(item, url, mediatype="video"):
    """Aplica propriedades mínimas e seguras para reprodução nativa rápida."""
    item.setProperty("IsPlayable", "true")
    item.setProperty("mediatype", mediatype or "video")
    _safe_call(item, "setMimeType", _mime_for_url(url))
    _safe_call(item, "setContentLookup", False)
    return item


def choose_playback_url(url, fallback_url=""):
    """Escolhe sempre a URL TS nativa quando ela existir."""
    return fallback_url or url


def f4mtester_available():
    """Verifica se há proxy F4M disponível.

    O FILMOM usa o F4MTESTER externo quando ele está instalado, mas também
    possui um proxy interno compatível. Assim, o modo F4M continua disponível
    mesmo se o usuário remover ou desativar ``plugin.video.f4mTester``.
    """
    try:
        addon = xbmcaddon.Addon(F4MTESTER_ADDON_ID)
        addon.getAddonInfo("id")
        return True
    except Exception:
        pass
    try:
        from resources.lib import f4m_proxy  # noqa: F401
        return True
    except Exception:
        return False


def _f4mtester_stream_url(url):
    """Prepara a URL no formato mais tolerante para o F4MTESTER 4.2.5.

    O roteador do F4MTESTER faz um parse simples usando `split('=')` e pode
    quebrar URLs que chegam ao Kodi já decodificadas com `&`, `=` ou headers
    anexados por `|`. Por isso, enviamos somente a URL base do stream.
    """
    base, _headers = _split_url_headers(url)
    return base


def f4mtester_url(url, title="FILMOM", thumb=""):
    """Monta a URL de chamada tradicional do F4MTESTER 4.2.5.

    Esta URL permanece disponível apenas como compatibilidade diagnóstica. No
    Kodi 21, resolver o item do FILMOM para `plugin://plugin.video.f4mTester`
    faz o Kodi marcar o item original como não reproduzível, porque o F4MTESTER
    toca por `xbmc.Player().play()` e não devolve `setResolvedUrl` ao FILMOM.
    """
    safe_url = urllib.parse.quote_plus(_f4mtester_stream_url(url))
    query_parts = [
        "action=playitem",
        "url=" + safe_url,
        "name=" + urllib.parse.quote_plus(title or "FILMOM"),
    ]
    if thumb:
        encoded_thumb = urllib.parse.quote_plus(thumb)
        query_parts.append("iconImage=" + encoded_thumb)
        query_parts.append("iconimage=" + encoded_thumb)
    return "plugin://%s/?%s" % (F4MTESTER_ADDON_ID, "&".join(query_parts))


def _f4mtester_proxy_check_url(path="/check"):
    return "http://%s:%s%s" % (F4MTESTER_PROXY_HOST, F4MTESTER_PROXY_PORT, path)


def _f4mtester_proxy_alive():
    try:
        request = urllib.request.Request(_f4mtester_proxy_check_url(), method="HEAD")
        response = urllib.request.urlopen(request, timeout=1)
        try:
            return response.getcode() == 200
        finally:
            response.close()
    except Exception:
        return False


def _f4mtester_proxy_url(url):
    prepared = _f4mtester_stream_url(url).replace("|", "&h123=true&")
    return _f4mtester_proxy_check_url("/?url=" + urllib.parse.quote_plus(prepared))


def _load_f4mtester_server_module():
    try:
        addon = xbmcaddon.Addon(F4MTESTER_ADDON_ID)
        addon_path = addon.getAddonInfo("path")
        server_path = os.path.join(addon_path, "server.py")
        if os.path.exists(server_path):
            module_name = "filmom_external_f4mtester_server"
            spec = importlib.util.spec_from_file_location(module_name, server_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            return module
    except Exception as exc:
        try:
            xbmc.log("[FILMOM] F4MTESTER externo indisponível, usando proxy interno: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
    from resources.lib import f4m_proxy
    return f4m_proxy


def _start_f4mtester_proxy():
    if _f4mtester_proxy_alive():
        return True
    try:
        server_module = _load_f4mtester_server_module()
        server_module.mediaserver().start()
    except Exception:
        return _f4mtester_proxy_alive()
    return _f4mtester_proxy_alive()


def _stop_f4mtester_proxy_when_done():
    def monitor():
        time.sleep(8)
        idle_rounds = 0
        while idle_rounds < 3:
            try:
                if xbmc.Player().isPlaying():
                    idle_rounds = 0
                else:
                    idle_rounds += 1
            except Exception:
                idle_rounds += 1
            time.sleep(2)
        try:
            urllib.request.urlopen(_f4mtester_proxy_check_url("/stop"), timeout=2).close()
        except Exception:
            pass
    try:
        thread = threading.Thread(target=monitor)
        thread.start()
    except Exception:
        pass


def resolve_f4mtester(url, title="FILMOM", thumb="", fanart="", plot="", fallback_url=""):
    selected_url = choose_playback_url(url, fallback_url)
    if not selected_url:
        xbmcgui.Dialog().notification("FILMOM", "URL de reprodução inválida.", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        return
    if not f4mtester_available():
        xbmcgui.Dialog().notification("FILMOM", "Proxy F4M indisponível. Usando NATIVO.", xbmcgui.NOTIFICATION_WARNING, 5000)
        item = playable_item(title, selected_url, thumb, fanart, plot)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        return
    if not _start_f4mtester_proxy():
        xbmcgui.Dialog().notification("FILMOM", "Proxy F4M não iniciou. Usando NATIVO.", xbmcgui.NOTIFICATION_WARNING, 5000)
        item = playable_item(title, selected_url, thumb, fanart, plot)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        return
    proxy_url = _f4mtester_proxy_url(selected_url)
    item = xbmcgui.ListItem(label=title or "FILMOM")
    art = thumb or fanart
    if art or fanart:
        item.setArt({"icon": art, "thumb": art, "poster": art, "fanart": fanart or thumb})
    item.setInfo("video", {
        "title": title or "FILMOM",
        "plot": plot or "Sinopse não informada pelo servidor.",
        "mediatype": "video"
    })
    item.setProperty("IsPlayable", "true")
    item.setProperty("FILMOM.Player", "F4MTESTER_PROXY")
    _safe_call(item, "setMimeType", "application/vnd.apple.mpegurl")
    _safe_call(item, "setContentLookup", False)
    item.setPath(proxy_url)
    _stop_f4mtester_proxy_when_done()
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def playable_item(title, url, thumb="", fanart="", plot="", mediatype="video"):
    item = xbmcgui.ListItem(label=title or "FILMOM")
    art = thumb or fanart
    item.setArt({"icon": art, "thumb": art, "poster": art, "fanart": fanart or thumb})
    item.setInfo("video", {
        "title": title or "FILMOM",
        "plot": plot or "Sinopse não informada pelo servidor.",
        "mediatype": mediatype or "video"
    })
    apply_fast_playback_properties(item, url, mediatype)
    item.setPath(_url_with_headers(url))
    return item


def resolve(url, title="FILMOM", thumb="", fanart="", plot="", fallback_url=""):
    try:
        from resources.lib import config
        active_player = config.get_active_player_id()
    except Exception:
        active_player = "native_ts"
    if active_player == "f4mtester":
        resolve_f4mtester(url, title, thumb, fanart, plot, fallback_url=fallback_url)
        return
    if not url and not fallback_url:
        xbmcgui.Dialog().notification("FILMOM", "URL de reprodução inválida.", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        return
    selected_url = choose_playback_url(url, fallback_url)
    item = playable_item(title, selected_url, thumb, fanart, plot)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def add_context_play_properties(item, url):
    return apply_fast_playback_properties(item, url)
