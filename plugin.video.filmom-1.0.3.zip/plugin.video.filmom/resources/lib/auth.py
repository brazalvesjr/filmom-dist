# -*- coding: utf-8 -*-
"""Controle de acesso remoto do FILMOM por JSON público protegido.

O addon solicita a senha do cliente na abertura. A senha não é comparada contra
um campo público: ela é usada para abrir o pacote protegido do cliente. Quando a
senha está correta, os servidores descriptografados são instalados apenas no
perfil local do Kodi.
"""

from __future__ import absolute_import, unicode_literals

import hashlib
import json
import time

import xbmc
import xbmcgui

from resources.lib import config, crypto_box

AUTH_FILE_NAME = "filmom_auth.json"
PASSWORD_PROMPT = "DIGITE A SENHA DO CLIENTE"


def auth_path():
    return config.os.path.join(config.profile_dir(), AUTH_FILE_NAME)


def sha256_text(value):
    return hashlib.sha256((value or "").encode("utf-8")).hexdigest()


def load_local_auth():
    path = auth_path()
    if config.xbmcvfs.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}
    return {}


def save_local_auth(data):
    data = data or {}
    data["updated_at"] = int(time.time())
    data["auth_version"] = 3
    with open(auth_path(), "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False, sort_keys=True)


def clear_local_auth():
    try:
        config.os.remove(auth_path())
    except Exception:
        pass


def fetch_clients_json():
    data = config.fetch_remote_config(use_cache=True)
    return data if isinstance(data, dict) else None


def _is_false(value):
    return str(value).strip().lower() in ("false", "0", "no", "nao", "não", "off")


def _client_active(client):
    if _is_false(client.get("active", client.get("ativo", True))):
        return False
    expires = (client.get("expires") or client.get("expira") or "").strip()
    if expires:
        try:
            today = time.strftime("%Y-%m-%d")
            if expires < today:
                return False
        except Exception:
            pass
    return True


def _clients_from_data(data):
    if not isinstance(data, dict):
        return []
    clients = data.get("clients") or data.get("clientes") or []
    if isinstance(clients, dict):
        converted = []
        for key, value in clients.items():
            if isinstance(value, dict):
                value.setdefault("id", key)
                converted.append(value)
        clients = converted
    return clients if isinstance(clients, list) else []


def _protected_box(client):
    if not isinstance(client, dict):
        return None
    for key in ("protected_config", "protected", "config", "box"):
        value = client.get(key)
        if isinstance(value, dict):
            return value
    return None


def _legacy_password_matches(client, typed_password):
    """Compatibilidade temporária com JSON antigo; não será usado no arquivo público."""
    typed_hash = sha256_text(typed_password)
    hashes = []
    plain_values = []
    for key in ("sha256", "password_sha256", "senha_sha256", "hash"):
        value = client.get(key)
        if value:
            hashes.append(str(value).strip().lower())
    for key in ("password", "senha", "pass"):
        value = client.get(key)
        if value is not None:
            plain_values.append(str(value))
    return typed_hash in hashes or typed_password in plain_values


def find_client_by_id(data, client_id):
    if not client_id:
        return None
    for client in _clients_from_data(data):
        if isinstance(client, dict) and str(client.get("id", "")) == str(client_id):
            return client
    return None


def find_client_with_password(data, password):
    for client in _clients_from_data(data):
        if not isinstance(client, dict) or not _client_active(client):
            continue
        box = _protected_box(client)
        if box:
            payload = crypto_box.open_payload(password, box)
            if payload:
                return client, payload
        elif _legacy_password_matches(client, password):
            return client, None
    return None, None


def validate_cached_access(remote_data):
    local = load_local_auth()
    if not local.get("authorized") or not remote_data:
        return False
    client_id = local.get("client_id")
    client = find_client_by_id(remote_data, client_id)
    if not client or not _client_active(client):
        clear_local_auth()
        return False
    if config.has_credentials():
        save_local_auth({"authorized": True, "client_id": client_id})
        return True
    return False


def ask_client_password():
    dialog = xbmcgui.Dialog()
    return dialog.input(PASSWORD_PROMPT, option=xbmcgui.ALPHANUM_HIDE_INPUT)


def ask_password_and_validate(remote_data):
    dialog = xbmcgui.Dialog()
    for attempt in range(3):
        password = ask_client_password()
        if not password:
            return False
        client, payload = find_client_with_password(remote_data, password)
        if client:
            client_id = client.get("id", "cliente")
            if payload:
                payload.setdefault("client_id", client_id)
                if not config.install_protected_payload(client_id, payload):
                    dialog.ok("FILMOM", "Senha aceita, mas nenhum servidor válido foi encontrado para este cliente.")
                    return False
            save_local_auth({"authorized": True, "client_id": client_id})
            dialog.notification("FILMOM", "Acesso liberado.", xbmcgui.NOTIFICATION_INFO, 2500)
            return True
        dialog.notification("FILMOM", "Senha inválida ou bloqueada.", xbmcgui.NOTIFICATION_ERROR, 3500)
    clear_local_auth()
    return False


def require_access():
    """Bloqueia o addon até que a senha do cliente abra um pacote protegido."""
    remote_data = fetch_clients_json()

    if remote_data and _is_false(remote_data.get("enabled", True)):
        xbmcgui.Dialog().ok("FILMOM", remote_data.get("message", "O acesso ao FILMOM está temporariamente bloqueado."))
        return False

    if remote_data and validate_cached_access(remote_data):
        return True

    if remote_data:
        return ask_password_and_validate(remote_data)

    ask_client_password()
    xbmcgui.Dialog().ok(
        "FILMOM",
        "Não foi possível acessar o JSON público de clientes. Verifique se o arquivo de distribuição está publicado e se a URL está correta."
    )
    return False
