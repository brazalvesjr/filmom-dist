# -*- coding: utf-8 -*-
"""Configuração persistente do FILMOM.

A base operacional do addon foi desenhada para manter a interface limpa: a troca
de servidores exibe apenas números, enquanto URL, usuário e senha podem ser
mantidos no JSON remoto do GitHub ou, em último caso, nas configurações internas
do Kodi.
"""

from __future__ import absolute_import, unicode_literals

import base64
import json
import os
import time
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.filmom"
ADDON = xbmcaddon.Addon(ADDON_ID)
CONFIG_VERSION = 3
CONFIG_FILE_NAME = "filmom_config.json"
REMOTE_CACHE_FILE_NAME = "filmom_remote_config.json"
USER_AGENT = "FILMOM-Config/1.0"


def _translate(path):
    try:
        return xbmcvfs.translatePath(path)
    except AttributeError:
        return xbmc.translatePath(path)


def profile_dir():
    path = _translate(ADDON.getAddonInfo("profile"))
    if not xbmcvfs.exists(path):
        try:
            xbmcvfs.mkdirs(path)
        except Exception:
            os.makedirs(path, exist_ok=True)
    return path


def config_path():
    return os.path.join(profile_dir(), CONFIG_FILE_NAME)


def remote_cache_path():
    return os.path.join(profile_dir(), REMOTE_CACHE_FILE_NAME)


def get_setting(key, default=""):
    value = ADDON.getSetting(key)
    return value if value not in (None, "") else default


def set_setting(key, value):
    ADDON.setSetting(key, value if value is not None else "")


def normalize_url(url):
    url = (url or "").strip()
    if url and not url.startswith(("http://", "https://")):
        url = "http://" + url
    return url.rstrip("/")


def _obfuscate(value):
    value = value or ""
    raw = value.encode("utf-8")
    return "b64:" + base64.urlsafe_b64encode(raw).decode("ascii")


def _deobfuscate(value):
    value = value or ""
    if not value.startswith("b64:"):
        return value
    try:
        return base64.urlsafe_b64decode(value[4:].encode("ascii")).decode("utf-8")
    except Exception:
        return ""


def default_config():
    return {
        "config_version": CONFIG_VERSION,
        "updated_at": int(time.time()),
        "active_server": get_setting("active_server_name", "Servidor 1") or "Servidor 1",
        "servers": []
    }


def load_config():
    path = config_path()
    data = default_config()
    if xbmcvfs.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as handle:
                loaded = json.load(handle)
            if isinstance(loaded, dict):
                data.update(loaded)
        except Exception as exc:
            xbmc.log("[FILMOM] Falha ao carregar configuração local: %s" % exc, xbmc.LOGWARNING)
    data.pop("clients", None)
    return ensure_initial_server(data)


def save_config(data):
    data = data or default_config()
    data["config_version"] = CONFIG_VERSION
    data["updated_at"] = int(time.time())
    data.pop("clients", None)
    with open(config_path(), "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False, sort_keys=True)


def _timeout():
    try:
        return max(5, int(get_setting("network_timeout", "18") or 18))
    except Exception:
        return 18


def remote_json_url():
    return (get_setting("clients_json_url", "") or "").strip()


def _read_cached_remote():
    path = remote_cache_path()
    if xbmcvfs.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as handle:
                cached = json.load(handle)
            return cached if isinstance(cached, dict) else {}
        except Exception:
            return {}
    return {}


def _save_cached_remote(data):
    try:
        with open(remote_cache_path(), "w", encoding="utf-8") as handle:
            json.dump(data or {}, handle, indent=2, ensure_ascii=False, sort_keys=True)
    except Exception as exc:
        xbmc.log("[FILMOM] Falha ao salvar cache remoto: %s" % exc, xbmc.LOGWARNING)


def fetch_remote_config(use_cache=True):
    url = remote_json_url()
    if not url or "SEU-USUARIO" in url:
        return _read_cached_remote() if use_cache else {}
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=_timeout()) as response:
            raw = response.read().decode("utf-8", "ignore")
        data = json.loads(raw)
        if isinstance(data, dict):
            _save_cached_remote(data)
            return data
    except Exception as exc:
        xbmc.log("[FILMOM] Falha ao buscar configuração remota: %s" % exc, xbmc.LOGWARNING)
    return _read_cached_remote() if use_cache else {}


def _plain(value):
    return str(value or "").strip()


def _normalize_remote_servers(remote):
    raw_servers = remote.get("servers") or remote.get("servidores") or []
    if isinstance(raw_servers, dict):
        raw_servers = list(raw_servers.values())
    servers = []
    for index, item in enumerate(raw_servers, start=1):
        if not isinstance(item, dict):
            continue
        active_value = str(item.get("active", item.get("ativo", True))).lower()
        if active_value in ("false", "0", "no", "nao", "não"):
            continue
        number = item.get("number") or item.get("numero") or item.get("n") or index
        name = "Servidor %s" % number
        url = normalize_url(item.get("url") or item.get("server_url") or item.get("host") or "")
        username = _plain(item.get("username") or item.get("user") or item.get("usuario") or item.get("usuário"))
        password = _plain(item.get("password") or item.get("senha") or item.get("pass"))
        if url and username and password:
            servers.append({"name": name, "number": str(number), "url": url, "username": username, "password": _obfuscate(password), "remote": True})
    return servers


def remote_servers():
    return _normalize_remote_servers(fetch_remote_config(use_cache=True))


def install_protected_payload(client_id, payload):
    """Instala localmente os servidores descriptografados do cliente autorizado."""
    payload = payload or {}
    servers = _normalize_remote_servers({"servers": payload.get("servers") or payload.get("servidores") or []})
    if not servers:
        xbmc.log("[FILMOM] Pacote protegido não contém servidores válidos.", xbmc.LOGWARNING)
        return False

    current = default_config()
    try:
        path = config_path()
        if xbmcvfs.exists(path):
            with open(path, "r", encoding="utf-8") as handle:
                loaded = json.load(handle)
            if isinstance(loaded, dict):
                current.update(loaded)
    except Exception:
        pass

    active = current.get("active_server") or get_setting("active_server_name", "Servidor 1") or "Servidor 1"
    available_names = [server.get("name") for server in servers]
    if active not in available_names:
        active = servers[0].get("name", "Servidor 1")

    current["client_id"] = client_id or payload.get("client_id") or "cliente"
    current["protected_remote"] = True
    current["servers"] = servers
    current["active_server"] = active
    save_config(current)
    sync_active_to_settings(current)
    return True


def ensure_initial_server(data):
    servers = data.get("servers") or []
    settings_url = normalize_url(get_setting("server_url"))
    settings_user = get_setting("username")
    settings_pass = get_setting("password")
    active_name = data.get("active_server") or get_setting("active_server_name", "Servidor 1") or "Servidor 1"

    if settings_url and settings_user and settings_pass:
        found = False
        for server in servers:
            if server.get("name") == active_name:
                server.update({"url": settings_url, "username": settings_user, "password": _obfuscate(settings_pass), "number": _server_number(active_name)})
                found = True
                break
        if not found:
            servers.append({"name": active_name, "number": _server_number(active_name), "url": settings_url, "username": settings_user, "password": _obfuscate(settings_pass)})
    elif not servers:
        servers.append({"name": "Servidor 1", "number": "1", "url": "", "username": "", "password": _obfuscate("")})

    data["servers"] = servers
    data["active_server"] = active_name
    save_config(data)
    sync_active_to_settings(data)
    return data


def _server_number(name):
    text = str(name or "Servidor 1")
    digits = "".join(ch for ch in text if ch.isdigit())
    return digits or "1"


def _all_servers(data=None):
    remotes = remote_servers()
    if remotes:
        return remotes
    data = data or load_config()
    servers = data.get("servers") or []
    for index, server in enumerate(servers, start=1):
        server.setdefault("number", _server_number(server.get("name") or index))
    return servers


def sync_active_to_settings(data):
    server = get_active_server(data)
    if not server:
        return
    set_setting("active_server_name", server.get("name", "Servidor 1"))
    if not server.get("remote"):
        set_setting("server_url", server.get("url", ""))
        set_setting("username", server.get("username", ""))
        set_setting("password", _deobfuscate(server.get("password", "")))
    else:
        set_setting("server_url", "")
        set_setting("username", "")
        set_setting("password", "")


def get_servers(data=None):
    return _all_servers(data)


def get_active_server(data=None):
    data = data or load_config()
    active = data.get("active_server") or get_setting("active_server_name", "Servidor 1") or "Servidor 1"
    servers = _all_servers(data)
    for server in servers:
        if server.get("name") == active or str(server.get("number")) == _server_number(active):
            return server
    return servers[0] if servers else None


def get_active_credentials():
    data = load_config()
    server = get_active_server(data) or {}
    return {
        "name": server.get("name", "Servidor 1"),
        "number": server.get("number", _server_number(server.get("name", "Servidor 1"))),
        "url": normalize_url(server.get("url", "")),
        "username": server.get("username", ""),
        "password": _deobfuscate(server.get("password", ""))
    }


def has_credentials():
    credentials = get_active_credentials()
    return bool(credentials["url"] and credentials["username"] and credentials["password"])


def add_or_update_server(name, url, username, password, make_active=True):
    data = load_config()
    name = (name or "Servidor 1").strip()
    if not name.lower().startswith("servidor"):
        name = "Servidor %s" % _server_number(name)
    url = normalize_url(url)
    servers = data.get("servers") or []
    found = False
    for server in servers:
        if server.get("name") == name:
            server.update({"number": _server_number(name), "url": url, "username": username or "", "password": _obfuscate(password or "")})
            found = True
            break
    if not found:
        servers.append({"name": name, "number": _server_number(name), "url": url, "username": username or "", "password": _obfuscate(password or "")})
    data["servers"] = servers
    if make_active:
        data["active_server"] = name
    save_config(data)
    sync_active_to_settings(data)
    return data


def remove_server(name):
    data = load_config()
    data["servers"] = [server for server in data.get("servers", []) if server.get("name") != name]
    if not data["servers"]:
        data["servers"] = [{"name": "Servidor 1", "number": "1", "url": "", "username": "", "password": _obfuscate("")}]
    if data.get("active_server") == name:
        data["active_server"] = data["servers"][0].get("name", "Servidor 1")
    save_config(data)
    sync_active_to_settings(data)
    return data


def select_server_dialog():
    data = load_config()
    servers = get_servers(data)
    if not servers:
        xbmcgui.Dialog().ok("FILMOM", "Nenhum servidor configurado no JSON do GitHub.")
        return
    labels = []
    active_name = (get_active_server(data) or {}).get("name")
    for server in servers:
        number = str(server.get("number") or _server_number(server.get("name")))
        labels.append("[COLOR gold]%s[/COLOR]" % number if server.get("name") == active_name else number)
    choice = xbmcgui.Dialog().select("TROCA DE SERVIDOR", labels)
    if choice < 0:
        return
    selected = servers[choice]
    data["active_server"] = selected.get("name")
    save_config(data)
    sync_active_to_settings(data)
    xbmcgui.Dialog().notification("FILMOM", "Servidor %s ativo." % selected.get("number", _server_number(selected.get("name"))), xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def server_wizard():
    xbmcgui.Dialog().ok("FILMOM", "Nenhum servidor foi liberado para esta senha. Verifique o clientes.json protegido publicado pelo administrador.")
    return False


def edit_active_server_dialog():
    return server_wizard()
