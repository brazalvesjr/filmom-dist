# -*- coding: utf-8 -*-
"""Camada de reprodução do FILMOM.

A reprodução é configurada para ser resiliente, com headers adequados e suporte a
HLS/inputstream quando disponível. Nenhum player consegue impedir quedas se a
origem, a internet ou a conta falharem, mas esta camada reduz interrupções comuns.
"""

from __future__ import absolute_import, unicode_literals

import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

USER_AGENT = "FILMOM/1.0 Kodi Addon"


def _has_inputstream_adaptive():
    try:
        xbmcaddon.Addon("inputstream.adaptive")
        return xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)")
    except Exception:
        return False


def playable_item(title, url, thumb="", fanart="", plot="", mediatype="video"):
    item = xbmcgui.ListItem(label=title or "FILMOM")
    item.setArt({"icon": thumb, "thumb": thumb, "poster": thumb, "fanart": fanart or thumb})
    item.setInfo("video", {
        "title": title or "FILMOM",
        "plot": plot or "Sinopse não informada pelo servidor.",
        "mediatype": mediatype
    })
    item.setProperty("IsPlayable", "true")
    item.setProperty("inputstreamaddon", "inputstream.adaptive")
    item.setProperty("inputstream.adaptive.stream_headers", "User-Agent=%s" % USER_AGENT)
    item.setProperty("inputstream.adaptive.manifest_headers", "User-Agent=%s" % USER_AGENT)
    item.setMimeType("application/vnd.apple.mpegurl" if ".m3u8" in url.lower() else "video/mp4")
    item.setPath(url + ("|User-Agent=%s" % USER_AGENT if "|" not in url else ""))
    return item


def resolve(url, title="FILMOM", thumb="", fanart="", plot=""):
    if not url:
        xbmcgui.Dialog().notification("FILMOM", "URL de reprodução inválida.", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        return
    item = playable_item(title, url, thumb, fanart, plot)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def add_context_play_properties(item, url):
    if ".m3u8" in (url or "").lower() and _has_inputstream_adaptive():
        item.setProperty("inputstream", "inputstream.adaptive")
        item.setProperty("inputstream.adaptive.manifest_type", "hls")
    item.setProperty("IsPlayable", "true")
    return item
