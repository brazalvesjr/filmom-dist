# -*- coding: utf-8 -*-
"""Camada de reprodução do FILMOM.

A reprodução mantém o modo NATIVO RÁPIDO (TS) como padrão e permite alternar
para o addon externo F4MTESTER quando o player nativo do Kodi estiver instável.
O F4MTESTER não é empacotado no FILMOM; ele é chamado somente quando instalado
no Kodi do usuário e selecionado na opção TROCA DE PLAYER.
"""

from __future__ import absolute_import, unicode_literals

import re
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

USER_AGENT = "Mozilla/5.0 (Linux; Android 11; Kodi) AppleWebKit/537.36 FILMOM/1.0"
F4MTESTER_ADDON_ID = "plugin.video.f4mTester"
COMMON_HEADERS = {
    "User-Agent": USER_AGENT,
    "Accept": "*/*",
    "Connection": "keep-alive",
    "Icy-MetaData": "0",
}


def _split_url_headers(url):
    if "|" not in (url or ""):
        return url or "", {}
    base, header_text = url.split("|", 1)
    parsed = {}
    for key, values in urllib.parse.parse_qs(header_text, keep_blank_values=True).items():
        if values:
            parsed[key] = values[-1]
    return base, parsed


def _headers_string(extra=None):
    headers = dict(COMMON_HEADERS)
    headers.update(extra or {})
    return urllib.parse.urlencode(headers)


def _url_with_headers(url, extra=None):
    base, existing = _split_url_headers(url)
    existing.update(extra or {})
    return base + "|" + _headers_string(existing)


def _extension_from_url(url):
    base, _headers = _split_url_headers(url)
    path = urllib.parse.urlparse(base).path.lower()
    match = re.search(r"\.([a-z0-9]{2,5})$", path)
    return match.group(1) if match else ""


def _mime_for_url(url):
    ext = _extension_from_url(url)
    if ext == "ts":
        return "video/mp2t"
    if ext == "mkv":
        return "video/x-matroska"
    if ext == "avi":
        return "video/x-msvideo"
    if ext == "m3u8":
        return "application/vnd.apple.mpegurl"
    return "video/mp4"


def _safe_call(obj, method, *args, **kwargs):
    try:
        getattr(obj, method)(*args, **kwargs)
    except Exception:
        pass


def apply_fast_playback_properties(item, url, mediatype="video"):
    """Aplica propriedades mínimas e seguras para reprodução nativa rápida."""
    item.setProperty("IsPlayable", "true")
    item.setProperty("mediatype", mediatype or "video")
    _safe_call(item, "setMimeType", _mime_for_url(url))
    _safe_call(item, "setContentLookup", False)
    return item


def choose_playback_url(url, fallback_url=""):
    """Escolhe sempre a URL TS nativa quando ela existir."""
    return fallback_url or url


def f4mtester_available():
    """Verifica se o addon externo F4MTESTER está instalado no Kodi."""
    try:
        addon = xbmcaddon.Addon(F4MTESTER_ADDON_ID)
        addon.getAddonInfo("id")
        return True
    except Exception:
        return False


def f4mtester_url(url, title="FILMOM", thumb=""):
    params = {
        "url": _url_with_headers(url),
        "name": title or "FILMOM",
    }
    if thumb:
        params["iconImage"] = thumb
    return "plugin://%s/?%s" % (F4MTESTER_ADDON_ID, urllib.parse.urlencode(params))


def resolve_f4mtester(url, title="FILMOM", thumb="", fanart="", plot="", fallback_url=""):
    selected_url = choose_playback_url(url, fallback_url)
    if not selected_url:
        xbmcgui.Dialog().notification("FILMOM", "URL de reprodução inválida.", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        return
    if not f4mtester_available():
        xbmcgui.Dialog().notification("FILMOM", "F4MTESTER não instalado. Usando NATIVO.", xbmcgui.NOTIFICATION_WARNING, 5000)
        item = playable_item(title, selected_url, thumb, fanart, plot)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
        return
    plugin_url = f4mtester_url(selected_url, title, thumb or fanart)
    xbmc.executebuiltin("RunPlugin(%s)" % plugin_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())


def playable_item(title, url, thumb="", fanart="", plot="", mediatype="video"):
    item = xbmcgui.ListItem(label=title or "FILMOM")
    art = thumb or fanart
    item.setArt({"icon": art, "thumb": art, "poster": art, "fanart": fanart or thumb})
    item.setInfo("video", {
        "title": title or "FILMOM",
        "plot": plot or "Sinopse não informada pelo servidor.",
        "mediatype": mediatype or "video"
    })
    apply_fast_playback_properties(item, url, mediatype)
    item.setPath(_url_with_headers(url))
    return item


def resolve(url, title="FILMOM", thumb="", fanart="", plot="", fallback_url=""):
    try:
        from resources.lib import config
        active_player = config.get_active_player_id()
    except Exception:
        active_player = "native_ts"
    if active_player == "f4mtester":
        resolve_f4mtester(url, title, thumb, fanart, plot, fallback_url=fallback_url)
        return
    if not url and not fallback_url:
        xbmcgui.Dialog().notification("FILMOM", "URL de reprodução inválida.", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        return
    selected_url = choose_playback_url(url, fallback_url)
    item = playable_item(title, selected_url, thumb, fanart, plot)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def add_context_play_properties(item, url):
    return apply_fast_playback_properties(item, url)
